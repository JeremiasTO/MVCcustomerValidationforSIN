﻿using System;

namespace DataClassLibrary
{
    public class Class1
    {
    }
}
